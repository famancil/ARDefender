﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class collisionManager : MonoBehaviour {

    private shipController ship;
    //public int scoreValue;

    //public Text scoreText;
    public int scoreValue;
	//public AudioSource[] sounds;
	//public AudioSource enemyExplosion;

    void Start() {

        GameObject gameObjectController = GameObject.FindWithTag("Player");

        if (gameObjectController != null) {

            ship = gameObjectController.GetComponent<shipController>();
        }
        if (ship == null) {

            Debug.Log("No hay script qlo");
        
        }

		//sounds = GetComponents<AudioSource> ();
		//enemyExplosion = sounds [1];
    }

    /*public void AddScore(int newScoreValue)
    {

        scoreValue = scoreValue + newScoreValue;
        UpdateScore();
    }

    public void UpdateScore()
    {

        scoreText.text = "Score: " + scoreValue;

    }*/

	void OnTriggerEnter(Collider other) //detecta colision con laser -> other
	{
		/*Debug.Log("1");
		Debug.Log(other);
		Debug.Log(other.gameObject);
		Debug.Log(gameObject.tag);
		*/

		//cuando el player ataca a una nave enemiga
		if (other.tag=="Missile")
		{
            GameObject explosion = Instantiate(Resources.Load("FlareMobile", typeof(GameObject))) as GameObject;
            explosion.transform.position = transform.position;
            //Destroy(col.gameObject);
            Destroy(explosion, 2);
			//Debug.Log("2");
			//enemyExplosion.Play ();
			Destroy(other.gameObject); //laser
			Destroy(gameObject); 		//enemy
            ship.AddScore(scoreValue);



		}
	}
}
