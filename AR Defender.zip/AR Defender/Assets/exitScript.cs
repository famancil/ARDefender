﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityStandardAssets.CrossPlatformInput;

public class exitScript : MonoBehaviour {

	//public Button exit;
	//public MobileSingleStickControl canvas;
    string activityName;

    public void onClick()
    {
    callJavaMethod();
    }


    private void callJavaMethod()
    {
    activityName = "HomeActivity";
    AndroidJavaClass jc = new AndroidJavaClass("com.unity3d.player.UnityPlayer");
    AndroidJavaObject jo = jc.GetStatic<AndroidJavaObject>("currentActivity");
    jo.Call("ReceiveUnityMessage", activityName); // Will call a method in Java with activityName as parameter
    }

	/*public void ExitApp()
	{
		
		Application.Quit();
	}*/

}
