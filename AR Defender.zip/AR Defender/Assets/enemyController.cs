﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class enemyController : MonoBehaviour {

	  // Use this for initialization
	public GameObject m_shotPrefab_enemy;
	private Rigidbody rb;
	//public AudioSource[] sounds;
	//public AudioSource laserShoot;
	/* 
	Transform myTransform;
	var moveSpeed = 3;
	var rotationSpeed = 3;
	*/
	Transform target;

	  void Start () {

        //Invoke("Move", 5);
        //Invoke("ShootAtPlayer", 5);
		rb = GetComponent<Rigidbody> ();
        rb.constraints = RigidbodyConstraints.FreezePositionZ | RigidbodyConstraints.FreezeRotationZ;
	    StartCoroutine ("Move");
		StartCoroutine ("ShootAtPlayer");
		target = GameObject.FindWithTag ("Player").transform; //target the player
		//sounds = GetComponents<AudioSource> ();
		//laserShoot = sounds [0];
	  }

	  // Update is called once per frame
	  void Update () {

	    transform.Translate(Vector3.forward * 3f * Time.deltaTime); 
	  }

	  IEnumerator Move() {

          while (true) {
		    yield return new WaitForSeconds (3.5f);
		    //transform.eulerAngles += new Vector3 (0, 180f, 0);
			//myTransform.rotation = Quaternion.Slerp (myTransform.rotation, Quaternion.LookRotation (target.position - myTransform.position), rotationSpeed * Time.deltaTime);
			transform.LookAt(target);
          }
  }

	IEnumerator ShootAtPlayer(){

		while (true) {

			int wait_time = Random.Range (0, 10);
			yield return new WaitForSeconds (wait_time);
			GameObject go = GameObject.Instantiate (m_shotPrefab_enemy, rb.position, rb.rotation) as GameObject;
			GameObject.Destroy (go, 3f);
			//laserShoot.Play ();

		}
	
	}

}

	   //for this to work both need colliders, one must have rigid body (spaceship) the other must have is trigger checked.
	 /* void OnCollisionEnter (Collision col)
	  {

	  	if (col.GameObject.name ="Enemy 1")
	  	{
	  		GameObject explosion = Instantiate(Resources.Load("FlareMobile", typeof(GameObject))) as GameObject;
		    explosion.transform.position = transform.position;
		    Destroy(col.gameObject);
		    Destroy (explosion, 2);
	  	}
	}*/
	/* void OnControllerColliderHit(ControllerColliderHit hit)
	  {

	  	 if(hit.gameObject.name == "Enemy 1")
	  	{
	  		GameObject explosion = Instantiate(Resources.Load("FlareMobile", typeof(GameObject))) as GameObject;
		    explosion.transform.position = transform.position;
		    Destroy(hit.gameObject);
		    Destroy (explosion, 2);
	  	}
	}*/
