﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityStandardAssets.CrossPlatformInput;
using UnityEngine.UI;


public class shipController : MonoBehaviour {
	public GameObject m_shotPrefab;
	private Rigidbody rb;
	private Animation anim;
	private Vector3 original_pos;
	public Text lifeText;
	private int life;
	public Text scoreText;
	private int score;
    /*AndroidJavaClass unityPlayer = new AndroidJavaClass("com.unity3d.player.UnityPlayer");
    AndroidJavaObject activity;
    string className = "com.jcordova.ARDefenderApp";
    AndroidJavaClass Intent;
    AndroidJavaObject sendIntent;*/
    

	//SONIDO
	//public AudioSource[] sounds;
	//public AudioSource laserShoot;
	//public AudioSource playerExplosion;
	//public AudioClip laser;

	// Use this for initialization
	void Start () {

        score = 0;
		life = 3;
		UpdateLife();
        UpdateScore();
		rb = GetComponent<Rigidbody> ();
		anim = GetComponent<Animation> ();
		//Vuforia.CameraDevice.Instance.SetFocusMode(Vuforia.CameraDevice.FocusMode.FOCUS_MODE_CONTINUOUSAUTO);
		original_pos = rb.transform.position;
        //AndroidJavaObject activity = unityPlayer.GetStatic<AndroidJavaObject>("currentActivity");
        //Intent = new AndroidJavaClass(className);
        //sendIntent = new AndroidJavaObject(className);
		//SONIDO
		/*sounds = GetComponents<AudioSource> ();
		Debug.Log (sounds);
		Debug.Log ("Primer audiosource: " + sounds [0].name);
		Debug.Log ("Segundo audiosource: " + sounds [1].name);
		laserShoot = sounds [0];
		playerExplosion = sounds [1];*/

	}

	/*public AudioSource getAudioSource (int position){
		//return sounds [position];
		return playerExplosion;
	}*/
	
	// Update is called once per frame
	void Update () {

		float x = CrossPlatformInputManager.GetAxis("Horizontal");
		float y = CrossPlatformInputManager.GetAxis("Vertical");

		Vector3 movement = new Vector3(x,0, y);

		rb.velocity = movement * 5f;

		if (x != 0 && y != 0)
		{
			transform.eulerAngles = new Vector3 (transform.eulerAngles.x, Mathf.Atan2(x,y) * Mathf.Rad2Deg, transform.eulerAngles.z);
		}
		/*
		if (x != 0 || y != 0)
		{
			anim.Play("Walk");
		} else
		{
			anim.Play("Idle");
		}
		*/
		
	}

	public void ShootLaser ()
	{
		GameObject go = GameObject.Instantiate(m_shotPrefab, rb.position, rb.rotation) as GameObject;
		GameObject.Destroy(go, 3f);
		//playerExplosion.PlayOneShot ("weapon_player", 1.0F);
	}

	public void ResetPosition()
	{
		GameObject player = GameObject.Find("Sketchfab_2015_09_29_19_40_53.blend");
		player.transform.position= original_pos;
		//Debug.Log(player.transform.position);
	}

    public void AddScore(int newScoreValue)
    {

        score += newScoreValue;
        //activity.Call("yourFunctionName", score);
        //sendIntent.Set<AndroidJavaObject>("gameRecord", score);
        //sendIntent.Call<AndroidJavaObject>("putExtra", score);
        //AndroidJavaObject jChooser = intentClass.CallStatic<AndroidJavaObject>("createChooser", sendIntent, "Share Via");
        //currentActivity.Call("startActivity", jChooser);
        UpdateScore();
    }

    public void UpdateScore()
    {

        scoreText.text = "Score: " + score;

    }

	public void setLife(int newLifeValue)
	{

		life = newLifeValue;
		UpdateLife();
	}

	public void UpdateLife()
	{

		lifeText.text = "Life: " + life;

	}
}
