﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class buttonsHandler : MonoBehaviour {

	public void ResetLevel()
	{
		/*crea enemigos*/
		GameObject player = GameObject.Find("Sketchfab_2015_09_29_19_40_53.blend");

		Vector3 random_position = new Vector3(Random.Range(-10.0f, 10.0f), player.transform.position.y, Random.Range(-10.0f, 10.0f));

		GameObject enemy1 = Instantiate(Resources.Load("Enemy 1", typeof(GameObject))) as GameObject;
		enemy1.transform.position=random_position;
		//enemy1.transform.position = new Vector3(10,player.position.y,0);
		//GameObject enemy2 = Instantiate(Resources.Load("Enemy 1", typeof(GameObject))) as GameObject;
		//enemy2.transform.position = new Vector3(0,player.position.y,0));
	}
}
