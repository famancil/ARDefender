﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class collisionsManagerAttackPlayer : MonoBehaviour {
	//public AudioSource[] sounds;
	//public AudioSource playerExplosion;
    
    public shipController ship;

	// Use this for initialization
	void Start() {
		

		GameObject gameObjectController = GameObject.FindWithTag("Player");

		if (gameObjectController != null) {

			ship = gameObjectController.GetComponent<shipController>();
		}
		if (ship == null) {

			Debug.Log("No hay script qlo");

		}
		//playerExplosion = ship.getAudioSource(1);
		//sounds = GetComponents<AudioSource> ();
		//playerExplosion = sounds [1];
	}

	// Update is called once per frame
	void Update () {
		
	}



	//public int scoreValue;

	//public Text scoreText;
	public int lifeValue;

	void OnTriggerEnter(Collider other) //detecta colision con laser -> other
	{

		/*Debug.Log("1");
		Debug.Log(other);
		Debug.Log(other.gameObject);
		Debug.Log(gameObject.tag);
		*/
		if (other.tag=="Missile_enemy" || other.tag == "Enemy")
		{
			//GameObject explosion = Instantiate(Resources.Load("FlareMobile", typeof(GameObject))) as GameObject;
			//explosion.transform.position = transform.position;
			//Destroy(col.gameObject);
			//Destroy(explosion, 1);
			//Debug.Log("Tag: " + other.tag);
			//Debug.Log("MISIL RECIBIDO");
			lifeValue -= 1;
			ship.setLife(lifeValue);
            GetComponent<AudioSource>().Play();
			Destroy(other.gameObject); //laser enemigo
			if (lifeValue == 0)
			{
                Debug.Log("Entro en la wea ");
				//playerExplosion.Play();
                GameObject explosion = Instantiate(Resources.Load("Explosion", typeof(GameObject))) as GameObject;
                explosion.transform.position = transform.position;
                Destroy(explosion, 2);
				//Destroy(other.gameObject); //laser
				Destroy(gameObject); 		//destroy player
                //Destroy(explosion, 1);
			}
			//ship.AddScore(scoreValue);

		}


	}
}
